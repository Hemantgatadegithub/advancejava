package beanpack;
import java.util.*;
public class MyClass4
{
	private List list;

	public void setList(List list)
	{
		this.list=list;
	}
	public List getList()
	{
		return list;
	}
}