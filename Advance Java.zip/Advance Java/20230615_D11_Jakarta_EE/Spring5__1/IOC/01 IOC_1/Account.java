package mypack;
public interface Account
{
   public void deposit();
}

