package mypack;
public class SavingAccountImpl implements Account 
{
	@Override
	public void deposit() 
	{
		System.out.println("inside saving deposit");
	}

}
