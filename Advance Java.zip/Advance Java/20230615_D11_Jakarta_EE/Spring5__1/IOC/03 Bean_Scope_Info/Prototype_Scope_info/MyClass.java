package mypack;
public class MyClass
{
	private String message;
public MyClass()
    {
        System.out.println("MyClass no-arg const");
    }
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
    
}
