package mypack;

public class Engine 
{
	public String dispEngine()
	{
		return "I am an engine";
	}
}
