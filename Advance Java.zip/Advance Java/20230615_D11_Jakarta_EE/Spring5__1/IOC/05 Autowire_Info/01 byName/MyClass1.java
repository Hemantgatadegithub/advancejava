package mypack;

public class MyClass1 
{
	public MyClass1() {
		System.out.println("in MyClass1 no-arg");
	}
	public void print()
	{
		System.out.println("in MyClass1 print");
	}
}
