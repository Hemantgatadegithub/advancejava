package mypack;
public class AnotherBean
{
    public String disp()
    {
        return "welcome to another bean";
    }
     public AnotherBean()
    {
        System.out.println("inside AnotherBean no-arg constr");
    }
}
