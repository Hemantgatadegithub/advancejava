package mypack;


public class MyBean {

	public String getMessage() {
		return "Hello from MyBean";
	}
}
