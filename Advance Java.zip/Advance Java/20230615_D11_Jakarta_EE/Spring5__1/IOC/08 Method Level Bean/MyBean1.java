package mypack;

import org.springframework.stereotype.Component;

@Component  
public class MyBean1 
{
	public int getValue()
	{
		return 100;
	}
}
