package mypack;
public class PojoClass   //  POJO - Plain old java object
{
	public String getMessage()
	{
		return "hello from PojoClass";
	}
}