package mypack1;
public class PojoClass1
{
	public String wish()
	{
		return "All the very best from PojoClass1";
	}
}